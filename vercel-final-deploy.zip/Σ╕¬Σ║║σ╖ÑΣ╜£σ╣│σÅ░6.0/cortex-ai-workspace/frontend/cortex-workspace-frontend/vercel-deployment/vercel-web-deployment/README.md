README.md created for web deployment
